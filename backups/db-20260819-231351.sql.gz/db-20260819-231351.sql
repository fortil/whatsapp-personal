--
-- PostgreSQL database dump
--

\restrict gcEepf3EgIN7UmfE79R4pRHpWm1mcxorcJbfA7rE5VkXVJbafXVKovBqd1gtJvU

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO postgres;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: birthday_source; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.birthday_source AS ENUM (
    'google',
    'manual'
);


ALTER TYPE public.birthday_source OWNER TO postgres;

--
-- Name: msg_direction; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.msg_direction AS ENUM (
    'in',
    'out'
);


ALTER TYPE public.msg_direction OWNER TO postgres;

--
-- Name: msg_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.msg_type AS ENUM (
    'text',
    'audio',
    'image',
    'video',
    'document',
    'sticker',
    'other'
);


ALTER TYPE public.msg_type OWNER TO postgres;

--
-- Name: task_kind; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.task_kind AS ENUM (
    'contacts_sync',
    'summarize',
    'contacts_export',
    'birthday_import',
    'birthday_calendar_sync'
);


ALTER TYPE public.task_kind OWNER TO postgres;

--
-- Name: task_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.task_status AS ENUM (
    'queued',
    'running',
    'done',
    'error'
);


ALTER TYPE public.task_status OWNER TO postgres;

--
-- Name: transcript_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.transcript_status AS ENUM (
    'none',
    'pending',
    'done',
    'error'
);


ALTER TYPE public.transcript_status OWNER TO postgres;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role AS ENUM (
    'user',
    'admin'
);


ALTER TYPE public.user_role OWNER TO postgres;

--
-- Name: user_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_status AS ENUM (
    'pending_verification',
    'pending_approval',
    'approved',
    'rejected',
    'suspended'
);


ALTER TYPE public.user_status OWNER TO postgres;

--
-- Name: verification_channel; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.verification_channel AS ENUM (
    'email',
    'sms'
);


ALTER TYPE public.verification_channel OWNER TO postgres;

--
-- Name: verification_purpose; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.verification_purpose AS ENUM (
    'signup_email',
    'signup_phone',
    'login',
    'password_reset',
    'email_change'
);


ALTER TYPE public.verification_purpose OWNER TO postgres;

--
-- Name: wa_state; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.wa_state AS ENUM (
    'connecting',
    'connected',
    'disconnected',
    'logged_out'
);


ALTER TYPE public.wa_state OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: postgres
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: postgres
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: postgres
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: birthday_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.birthday_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    contact_id uuid NOT NULL,
    google_event_id text,
    calendar_id text DEFAULT 'primary'::text NOT NULL,
    last_verified_at timestamp with time zone
);


ALTER TABLE public.birthday_events OWNER TO postgres;

--
-- Name: contacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contacts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    wa_jid text NOT NULL,
    phone_e164 text,
    is_lid boolean DEFAULT false NOT NULL,
    merged_into_contact_id uuid,
    display_name text,
    wa_name text,
    birth_month integer,
    birth_day integer,
    birth_year integer,
    birthday_source public.birthday_source,
    google_resource_name text
);


ALTER TABLE public.contacts OWNER TO postgres;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    contact_id uuid,
    wa_jid text NOT NULL,
    last_message_at timestamp with time zone,
    summary text,
    summary_model text,
    summary_updated_at timestamp with time zone,
    summary_thru_created_at timestamp with time zone
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- Name: google_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.google_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    google_email text NOT NULL,
    refresh_token_enc text NOT NULL,
    scopes text NOT NULL,
    people_sync_token text,
    connected_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


ALTER TABLE public.google_accounts OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid NOT NULL,
    user_id uuid NOT NULL,
    external_id text,
    direction public.msg_direction NOT NULL,
    type public.msg_type DEFAULT 'text'::public.msg_type NOT NULL,
    body text,
    media_mime text,
    read_at timestamp with time zone,
    transcript text,
    transcript_status public.transcript_status DEFAULT 'none'::public.transcript_status NOT NULL,
    transcript_model text,
    transcribed_at timestamp with time zone,
    sent_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    raw jsonb,
    transcribe_started_at timestamp with time zone
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: task_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    kind public.task_kind NOT NULL,
    status public.task_status DEFAULT 'queued'::public.task_status NOT NULL,
    processed integer DEFAULT 0 NOT NULL,
    total integer DEFAULT 0 NOT NULL,
    file_path text,
    error text,
    params jsonb,
    bullmq_job_id text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone
);


ALTER TABLE public.task_runs OWNER TO postgres;

--
-- Name: trusted_devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trusted_devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    user_agent text,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.trusted_devices OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    phone text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    role public.user_role DEFAULT 'user'::public.user_role NOT NULL,
    status public.user_status DEFAULT 'pending_verification'::public.user_status NOT NULL,
    email_verified_at timestamp with time zone,
    phone_verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    approved_by uuid,
    rejected_reason text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: verification_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verification_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    channel public.verification_channel NOT NULL,
    purpose public.verification_purpose NOT NULL,
    code_hash text,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.verification_codes OWNER TO postgres;

--
-- Name: wa_instances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wa_instances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    instance_name text NOT NULL,
    state public.wa_state DEFAULT 'connecting'::public.wa_state NOT NULL,
    connected_jid text,
    last_state_at timestamp with time zone
);


ALTER TABLE public.wa_instances OWNER TO postgres;

--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: postgres
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	753a17e67a1693645923914b161b1d10619b1a040a648fb60f53e4d0344b6a0f	1787152154962
2	e7bd380a315e61c5489a953c278f7fdbb705033575cd3e681d8f33013cda761a	1787161819999
\.


--
-- Data for Name: birthday_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.birthday_events (id, user_id, contact_id, google_event_id, calendar_id, last_verified_at) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contacts (id, user_id, wa_jid, phone_e164, is_lid, merged_into_contact_id, display_name, wa_name, birth_month, birth_day, birth_year, birthday_source, google_resource_name) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversations (id, user_id, contact_id, wa_jid, last_message_at, summary, summary_model, summary_updated_at, summary_thru_created_at) FROM stdin;
\.


--
-- Data for Name: google_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.google_accounts (id, user_id, google_email, refresh_token_enc, scopes, people_sync_token, connected_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, conversation_id, user_id, external_id, direction, type, body, media_mime, read_at, transcript, transcript_status, transcript_model, transcribed_at, sent_at, created_at, raw, transcribe_started_at) FROM stdin;
\.


--
-- Data for Name: task_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_runs (id, user_id, kind, status, processed, total, file_path, error, params, bullmq_job_id, updated_at, finished_at) FROM stdin;
\.


--
-- Data for Name: trusted_devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trusted_devices (id, user_id, token_hash, user_agent, last_used_at, expires_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, phone, email, password_hash, role, status, email_verified_at, phone_verified_at, approved_at, approved_by, rejected_reason) FROM stdin;
b7094d6d-41b8-4ea1-8ab2-8347d1dece2f	+573001234567	admin@example.com	f3e731a19ce0dd436c29ae552ffc0cbe:7cf1903059ba414bad4714c6e28aca0bcc3d88c6ebfc418f66d2b6234f2db63efcba8b1056a2c263b41d6df92c4383a7eabe7f6740a313ff66e7445a64db8e86	admin	approved	2026-08-19 15:17:07.734+00	2026-08-19 15:17:07.734+00	2026-08-19 15:17:07.734+00	\N	\N
\.


--
-- Data for Name: verification_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verification_codes (id, user_id, channel, purpose, code_hash, expires_at, consumed_at, attempts) FROM stdin;
52c7daa3-b6ea-424d-9a02-266edd8a8d60	b7094d6d-41b8-4ea1-8ab2-8347d1dece2f	email	login	dad4775ea7baf8d1a0d646b309146861fcc18c465efd81b5690d161db966992e	2026-08-19 16:29:35.81+00	2026-08-19 16:14:36.854+00	1
0ac6aa7b-7a46-459d-9473-90d912a56889	b7094d6d-41b8-4ea1-8ab2-8347d1dece2f	email	login	e541f41a9fcb2f3fa4dac6bd8b0dc1f45cf8cb341f7ba299958618f6d0036d02	2026-08-19 16:10:50.917+00	2026-08-19 15:55:51.971+00	1
\.


--
-- Data for Name: wa_instances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wa_instances (id, user_id, instance_name, state, connected_jid, last_state_at) FROM stdin;
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: postgres
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 2, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: birthday_events birthday_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.birthday_events
    ADD CONSTRAINT birthday_events_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: google_accounts google_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.google_accounts
    ADD CONSTRAINT google_accounts_pkey PRIMARY KEY (id);


--
-- Name: google_accounts google_accounts_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.google_accounts
    ADD CONSTRAINT google_accounts_user_id_unique UNIQUE (user_id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: task_runs task_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_runs
    ADD CONSTRAINT task_runs_pkey PRIMARY KEY (id);


--
-- Name: trusted_devices trusted_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_pkey PRIMARY KEY (id);


--
-- Name: trusted_devices trusted_devices_token_hash_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_token_hash_unique UNIQUE (token_hash);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_phone_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_phone_unique UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verification_codes verification_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_codes
    ADD CONSTRAINT verification_codes_pkey PRIMARY KEY (id);


--
-- Name: wa_instances wa_instances_instance_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_instances
    ADD CONSTRAINT wa_instances_instance_name_unique UNIQUE (instance_name);


--
-- Name: wa_instances wa_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_instances
    ADD CONSTRAINT wa_instances_pkey PRIMARY KEY (id);


--
-- Name: wa_instances wa_instances_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_instances
    ADD CONSTRAINT wa_instances_user_id_unique UNIQUE (user_id);


--
-- Name: birthday_events_user_contact_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX birthday_events_user_contact_uq ON public.birthday_events USING btree (user_id, contact_id);


--
-- Name: contacts_user_jid_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX contacts_user_jid_uq ON public.contacts USING btree (user_id, wa_jid);


--
-- Name: contacts_user_phone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contacts_user_phone_idx ON public.contacts USING btree (user_id, phone_e164);


--
-- Name: conversations_user_jid_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX conversations_user_jid_uq ON public.conversations USING btree (user_id, wa_jid);


--
-- Name: conversations_user_last_message_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX conversations_user_last_message_idx ON public.conversations USING btree (user_id, last_message_at);


--
-- Name: messages_conversation_external_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX messages_conversation_external_uq ON public.messages USING btree (conversation_id, external_id) WHERE (external_id IS NOT NULL);


--
-- Name: messages_keyset_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX messages_keyset_idx ON public.messages USING btree (conversation_id, sent_at DESC NULLS LAST, id);


--
-- Name: messages_unread_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX messages_unread_idx ON public.messages USING btree (conversation_id) WHERE ((direction = 'in'::public.msg_direction) AND (read_at IS NULL));


--
-- Name: task_runs_status_updated_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_runs_status_updated_idx ON public.task_runs USING btree (status, updated_at);


--
-- Name: task_runs_user_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_runs_user_idx ON public.task_runs USING btree (user_id);


--
-- Name: trusted_devices_user_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX trusted_devices_user_idx ON public.trusted_devices USING btree (user_id);


--
-- Name: verification_codes_user_channel_purpose_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX verification_codes_user_channel_purpose_idx ON public.verification_codes USING btree (user_id, channel, purpose);


--
-- Name: birthday_events birthday_events_contact_id_contacts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.birthday_events
    ADD CONSTRAINT birthday_events_contact_id_contacts_id_fk FOREIGN KEY (contact_id) REFERENCES public.contacts(id);


--
-- Name: birthday_events birthday_events_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.birthday_events
    ADD CONSTRAINT birthday_events_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: contacts contacts_merged_into_contact_id_contacts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_merged_into_contact_id_contacts_id_fk FOREIGN KEY (merged_into_contact_id) REFERENCES public.contacts(id);


--
-- Name: contacts contacts_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: conversations conversations_contact_id_contacts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_contact_id_contacts_id_fk FOREIGN KEY (contact_id) REFERENCES public.contacts(id);


--
-- Name: conversations conversations_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: google_accounts google_accounts_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.google_accounts
    ADD CONSTRAINT google_accounts_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: messages messages_conversation_id_conversations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_conversations_id_fk FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: messages messages_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: task_runs task_runs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_runs
    ADD CONSTRAINT task_runs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: trusted_devices trusted_devices_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users users_approved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_approved_by_users_id_fk FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: verification_codes verification_codes_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_codes
    ADD CONSTRAINT verification_codes_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: wa_instances wa_instances_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_instances
    ADD CONSTRAINT wa_instances_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict gcEepf3EgIN7UmfE79R4pRHpWm1mcxorcJbfA7rE5VkXVJbafXVKovBqd1gtJvU

